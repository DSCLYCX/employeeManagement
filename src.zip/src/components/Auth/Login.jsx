import { useState } from 'react'
import { GrSecure } from "react-icons/gr";
const Login = () => {
  const [email, setEmail] = useState()
  const [password, setPassword] = useState('')


  const submitHandler = (e) => {
    e.preventDefault()
    console.log('email : ', email)
    console.log('pass : ', password)
    setEmail("")
    setPassword("")

  }
  return (

    <div className=' h-screen w-screen flex items-center justify-center pr-20 pl-10 bg-zinc-900 '>

      <div className=" px-3 py-3  flex flex-col items-center bg-white/20 shadow-2xl rounded-2xl  border-4 border-zinc-800 h-60 w-80 justify-between">
        <form onSubmit={(e) =>
          submitHandler(e)
        } className=' absolute px-3 py-10  flex flex-col items-center  rounded-2xl  h-56 w-56 justify-evenly'>
          <div className="absolute bottom-60 h-14 w-28 bg-white/20 border border-t-4 border-x-4 border-zinc-800 rounded-t-full flex items-center justify-center shadow-2xl">
            <GrSecure className='text-zinc-100 text-3xl' />
          </div>
          <h2 className='flex items-center justify-center text-white text-xl font-sm'>Email or Username</h2>
          <input value={email} onChange={(e) => {
            setEmail(e.target.value)
          }} required className='bg-zinc-100  transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 h-14 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 duration-500  shadow-2xl ' type="email" placeholder='Enter your E-mail' />
          <h2 className='text-white text-xl font-sm'>Password</h2>
          <input value={password} onChange={(e) => {
            setPassword(e.target.value)
          }} required className='bg-zinc-100 transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 h-14 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white outline-0 rounded-2xl hover:bg-zinc-950 duration-500 shadow-2xl' type="password" placeholder='Enter your Password' />
          <div className="transfonrm hover:scale-95 bg-white/20 absolute shadow-2xl bottom-[-40px] px-3   flex flex-col items-center  rounded-bl-2xl rounded-br-2xl  h-10 w-60 justify-between border-r-4 border-b-4 border-zinc-800 hover:bg-zinc-950 duration-500">
            <button className='text-white font-extrabold text-xl  '>Login</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default Login