import React from 'react'
import Header from '../others/Header'
import { MdOutlineArrowBackIos } from "react-icons/md";
const AdminDashboard = () => {
    return (
        <div className='bg-zinc-900   justify-center items-center'>
            <div className="  border-b-4 border-zinc-800 rounded-br-3xl rounded-bl-3xl bg-white/20  px-6 py-10  h-[13vh]  flex items-center gap-6">
                <div className="                    flex justify-between items-center gap-4 ">
                    <button className='h-12 w-12 px-[7px] bg-zinc-900 transform hover:scale-95  text-white rounded-full text-2xl border-4 hover:bg-zinc-800 hover:text-white  border-zinc-900  duration-200 '> <MdOutlineArrowBackIos /></button>
                </div>
                <div className="mb-3">
                    <h1 className='text-white text-6xl font-fg '>CreateTask</h1>
                </div>
            </div>
            <div className=" mt-5 flex justify-center items-center bg-zinc-900  h-[90vh]  ">
                <form className='flex flex-col items-center justify-center gap-4'>
                    <h1>Task Name</h1>
                    <input type="text" placeholder='Task Name' className=' w-[30vw] h-12 bg-zinc-100  transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 hover:text-white duration-500  shadow-2xl ' />
                   
                    <textarea name="" id="" cols="30" rows="10" placeholder='Task Description' className=' w-[30vw] h-12  bg-zinc-100 transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 w-38 px-4 py-2 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 hover:text-white duration-500  shadow-2xl '></textarea>
                    
                    <input type="date" placeholder='Task Status' className=' w-[30vw] h-12  bg-zinc-100 transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 hover:text-white duration-500  shadow-2xl' />
                   
                    <input type="text" placeholder='Assign To' className=' w-[30vw] h-12  bg-zinc-100 transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 hover:text-white duration-500  shadow-2xl' />
                    
                    <input type="text" placeholder='Category' className=' w-[30vw] h-12  bg-zinc-100 transfonrm hover:scale-105 border-r-4 border-b-4 border-zinc-800 w-38 px-4 text-xl text-zinc-700 hover:placeholder:text-white  outline-0 rounded-2xl hover:bg-zinc-950 hover:text-white duration-500  shadow-2xl' />

                    <button className='w- h-12 mt-6 px-2 bg-white transform hover:scale-95  text-zinc-900 rounded-xl text-2xl border-4 hover:bg-zinc-900 hover:text-white  border-zinc-800  duration-200  '>Create Task</button>


                </form>
            </div>
        </div>
    )
}
    
export default AdminDashboard