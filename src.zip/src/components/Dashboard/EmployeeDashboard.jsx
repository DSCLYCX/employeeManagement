import React from 'react'
import Header from '../others/Header'
import TasklishNumber from '../others/TasklishNumber'
import Tasklist from '../Tasklist/Tasklist'

const EmployeeDashboard = () => {
    return (
        <div className=' bg-zinc-900 h-[100vh]'>
            <Header/>
            <TasklishNumber />
            <Tasklist />
            <Tasklist />

        </div>

    )
}

export default EmployeeDashboard