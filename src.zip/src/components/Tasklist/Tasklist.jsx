import React from 'react'

const Tasklist = () => {
  return (

    <div className="h-[50%]  bg-zinc-900  flex flex-nowrap px-12 py-6 justify-start   gap-5 overflow-y-hidden no-scrollbar" >
      <div1 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div1>
      <div2 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div2>
      <div3 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div3>
      <div4 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div4>
      <div5 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div5>
      <div6 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div6>
      <div7 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div7>
      <div8 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw] rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div8>
      <div9 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw]  rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div9>
      <div10 className="flex-shrink-0 border-r-4 border-b-4 border-zinc-800 h-full w-[22vw]  rounded-3xl bg-white/20 hover:bg-zinc-900 duration-200 transfonrm hover:scale-95 "></div10>

    </div>



  )
}

export default Tasklist