import React from 'react'
import { LuSunMoon } from "react-icons/lu";
import { TbDoorExit } from "react-icons/tb";
const Header = () => {
  return (
    <div>
      <div className=" border-b-4 border-zinc-800 rounded-br-3xl rounded-bl-3xl bg-white/20  px-6 py-10  h-[13vh]  flex items-center justify-between">
        <div className="flex items-center   w-60 h-16">
          <img className=' h-14 w-14 rounded-full ' src="https://placeit-img-1-p.cdn.aws.placeit.net/uploads/stage/stage_image/171731/optimized_product_thumb_stage.jpg" />
          <h1 className=' px-6 leading-8 h-full w-full pt-3 font-fg font-semibold text-white text-4xl' >HI!Tasker </h1>
        </div>

        <div className="flex justify-between items-center gap-4 ">
         
          <button className='h-12 w-12 px-2 bg-white transform hover:scale-95  text-zinc-900 rounded-full text-2xl border-4 hover:bg-zinc-900 hover:text-white  border-zinc-800  duration-200 '> <TbDoorExit /></button>
        </div>
      </div>
    </div>
  )
}

export default Header