import React from 'react'
import { FaCircle } from "react-icons/fa6";
const TasklishNumber = () => {
  return (
    <div className=" bg-zinc-900 rounded-3xl ml-6 mt-5 justify-center w-[95vw] mr-6 px-5 py-5">
      <div className="flex px-2 py-2 justify-evenly gap-4 h-[200px] w-[92vw]">
        <div1 className=" border-r-4 border-b-4 border-zinc-800 h-44 w-72 rounded-3xl bg-white/20 hover:bg-zinc-900/65 duration-200 transfonrm hover:scale-95">
          <div className="flex justify-between items-center pr-4">
            <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee font-semibold'>3</h1>
            <h1 className='text-xl text-green-500 leading-3 animate-pulse'><FaCircle /></h1>
          </div>
          <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee font-semibold'>New Task</h1>
        </div1>
        <div2 className="border-r-4 border-b-4 border-zinc-800 h-44 w-72 rounded-3xl bg-white/20 hover:bg-zinc-900/65 duration-200 transfonrm hover:scale-95">
          <div className="flex justify-between items-center pr-4">
            <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee font-semibold'>3</h1>
            <h1 className='text-xl text-yellow-500 leading-3 animate-pulse'><FaCircle /></h1>
          </div> <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee  font-semibold'>In Progress</h1>
        </div2>
        <div3 className="border-r-4 border-b-4 border-zinc-800 h-44 w-72 rounded-3xl bg-white/20 hover:bg-zinc-900/65 duration-200 transfonrm hover:scale-95">
          <div className="flex justify-between items-center pr-4">
            <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee font-semibold'>3</h1>
            <h1 className='text-xl text-blue-500 leading-3 animate-pulse'><FaCircle /></h1>
          </div><h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee  font-semibold'>Completed</h1>
        </div3>
        <div4 className="border-r-4 border-b-4 border-zinc-800 h-44 w-72 rounded-3xl bg-white/20 hover:bg-zinc-900/65 duration-200 transfonrm hover:scale-95">
          <div className="flex justify-between items-center pr-4">
            <h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee font-semibold'>3</h1>
            <h1 className='text-xl text-red-500 leading-3 animate-pulse'><FaCircle /></h1>
          </div><h1 className='text-5xl px-4 py-8 text-zinc-100 leading-3 font-nuee  font-semibold'>Failed</h1>
        </div4>
      </div>



    </div>

  )
}

export default TasklishNumber